#! /bin/bash

bin/hdfs dfs -mkdir /user
bin/hdfs dfs -mkdir /user/rash
bin/hdfs dfs -mkdir /user/rash/wordcount
bin/hdfs dfs -mkdir /user/rash/wordcount/input
bin/hdfs dfsadmin -setSpaceQuota 10M /user/rash
bin/hdfs dfs -put examples/input/file01 /user/rash/wordcount/input/
bin/hdfs dfs -put examples/input/file02 /user/rash/wordcount/input/
