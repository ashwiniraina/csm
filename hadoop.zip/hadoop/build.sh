#! /bin/bash

hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/sbin/stop-all.sh
sudo rm -R /tmp/*
mvn package -Pdist -Dtar -DskipTests -Dmaven.javadoc.skip=true
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/core-site.xml hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/core-site.xml
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/hdfs-site.xml hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/hdfs-site.xml
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/yarn-site.xml hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/yarn-site.xml
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/mapred-site.xml hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/etc/hadoop/mapred-site.xml
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/setup.sh hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/setup.sh
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/start.sh hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/start.sh
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/restart.sh hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/restart.sh
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/test.sh hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/test.sh
cp -r ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/examples hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/
cp ../hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/setup.sh hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/setup.sh
cd hadoop-dist/target/hadoop-3.3.0-SNAPSHOT/
