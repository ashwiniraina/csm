#! /bin/bash

sbin/stop-all.sh
rm -R /tmp/*
bin/hdfs namenode -format
bin/hdfs dfsadmin -setSpaceQuota 10M /user/rash
sbin/start-dfs.sh
bin/hdfs dfsadmin -safemode leave
